/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BTVN4;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Student_Manager {

    public ArrayList<Student> students = new ArrayList<>(); // dsach ArrayList sẽ chứa các đối tượng thuộc lớp Student với tên dsach sẽ là biến tên students
    Scanner scanner = new Scanner(System.in);

    // Add hsinh mẫu
    public void addSampleStudent() {
        students.add(new Student("DC", 20, "IT"));
        students.add(new Student("GM", 23, "Marketing"));
        students.add(new Student("RH", 22, "Gamer"));

    }

    // 1. Xem danh sách sinh viên
    public void viewStudents() {
        if (students.isEmpty()) {
            System.out.println("Danh sách sinh viên trống.");
        } else {
            for (Student student : students) {
                System.out.println(student);

            }
        }

    }

    // 2. Thêm sinh viên
    public void addStudent() {
        System.out.println("Nhập tên sinh viên:");
        String name = scanner.nextLine();

        System.out.println("Nhập tuổi sinh viên:");
        int age1;
        if (age1 < 18) {
        int age = scanner.nextInt();
       System.out.println("Tuổi không hợp lệ, mời nhập lại");
        } else {
        scanner.nextLine();
        }

        System.out.println("Nhập ngành học:");
        String major = scanner.nextLine();

        students.add(new Student(name, age, major));

        System.out.println("Đã thêm sinh viên thành công. Mời bạn chọn số 1 để xem danh sách");
    }

    // Hàm thoát chương trình
    public void exitProgram() {
        System.out.println("Thoát chương trình.");
        System.exit(0);

    }

}
