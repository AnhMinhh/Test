/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BTVN4;
import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Menu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Student_Manager manager = new Student_Manager(); // Khai báo biến tên manager thuộc kiểu Student_Manager, biến manager này sẽ được dùng để truy cập tất cả các phương thức của lớp Student_Manager
        int choice;
        
           do {
            System.out.println("========= MENU =========");
            System.out.println("1. Xem danh sách sinh viên");
            System.out.println("2. Thêm sinh viên");
//            System.out.println("3. Xóa sinh viên");
//            System.out.println("4. Sửa thông tin sinh viên");
//            System.out.println("5. Tìm kiếm sinh viên theo tên");
            System.out.println("6. Thoát");
            System.out.println("========================");
            System.out.print("Chọn một lựa chọn: ");
            manager.addSampleStudent();
            
           
            choice = sc.nextInt();
            sc.nextLine();  // Clear buffer

            switch (choice) {
                case 1:
                    manager.viewStudents();
                    break;
                case 2:
                    manager.addStudent();
                    break;
               
                   
                case 6:
                    manager.exitProgram();
                    break;
                default:
                    System.out.println("Lựa chọn không hợp lệ.");
            }
        } while (choice != 6);
                    
                 
            }
    
    }

