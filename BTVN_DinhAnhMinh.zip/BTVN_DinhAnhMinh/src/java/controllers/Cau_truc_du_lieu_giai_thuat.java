/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/**
 *
 * @author DELL
 */
public class Cau_truc_du_lieu_giai_thuat {
    public static void main(String[] args) {
        ArrayList<String> alist = new ArrayList();
        alist.add("Anh Minh");
        alist.add("Anh Minh 1");
        
        
        //System.out.println(alist.get(0));
        
        LinkedList<String> llist = new LinkedList();
        llist.add("AM");
        llist.add("TM");
        llist.addFirst("LK");
        
        // Stack
        Stack<String> slist = new Stack();
        slist.push("Quoc Dung");
        slist.push("Hang");
        
        String a = slist.pop();
        //System.out.println(a); // in ra Hằng vì Hằng vào sau (quy tắc vào sau ra trước của Stack
        


        // Queue
        Queue<String> qlist = new LinkedList();
        qlist.add("Dung");
        qlist.add("Hang");
        //System.out.println(qlist.poll()); // in ra Dũng vì Dũng vào trước ( quy tắc vào trc ra trc)
        
        
        //HashMap
        HashMap<Integer, String> hlist = new HashMap<>();
        hlist.put(1, "Quoc Dung");
        hlist.put(2,"Anh Minh");
        hlist.put(3,"Hang");
        //System.out.println(hlist.get(2));
        
        
        //HashSet
       HashSet<String> setlist = new HashSet<>();
       setlist.add("Quoc Dung");
       setlist.add("Thanh");
       System.out.println(setlist);// Gọi 1 phát ra hết tất cả các phần tử
        
       
    // COLLECTION FRAMEWORK
        // add(): Thêm phần tử vào bộ sưu tập
        // remove(): xóa phần tử trong bộ sưu tập
        // contain(): kiểm tra xem bộ sưu tập có chứa 1 ptu cụ thể hay ko
        // size(): Trả về số lượng phần tử trong bộ sưu tập
        // clear(): xóa tất cả các phần tử tỏng bộ sưu tập
        //empty(): kiểm tra xem bộ sưu tập có rỗng ko aka có ptu nào ko
    }
}
