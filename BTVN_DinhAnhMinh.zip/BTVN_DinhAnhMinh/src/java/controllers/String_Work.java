/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

/**
 *
 * @author DELL
 */
public class String_Work {
    public static void main(String[] args) {
        String a = "VuDuc";
        String b = a.substring(1, 4);
        String c = "u";
        System.out.println(a.length());
        System.out.println(a.charAt(3));
        System.out.println(a.substring(1, 3)); // lấy các kí tự 0,1,2
        System.out.println(a.substring(1));
        System.out.println(b);

        System.out.println(a.indexOf(b));
        System.out.println(a.lastIndexOf(b));
        System.out.println(a.equals(b));
        System.out.println(a.equalsIgnoreCase(b));
        System.out.println(a.compareTo(b));
        System.out.println("...................");
        System.out.println(a.trim());
        System.out.println(c.toLowerCase());
        System.out.println(a.toUpperCase());
        System.out.println(a.concat(b));
        System.out.println(a.replace('u', 'm'));
        System.out.println(a.startsWith(c));
        String d = "Giang,Dung,Hang-Minh";
        String[] e = d.split("\\w");
        
        // Vòng for each tự động tạo ra 1 hàm tên là string có kiểu dữ liệu String giống kiểu dữ liệu mảng e. Tự động duyệt qua tất cả các kí tự trong mảng
        for (String string : e) {
            System.out.println(string);
        
            
        // Cách khai báo String Builder
        a = "Duong yeu";
        b = " Hang";
        StringBuilder sb = new StringBuilder();
        sb.append(a).append('\t').append(b);
        System.out.println(sb.toString());
            
        }
    }
}
