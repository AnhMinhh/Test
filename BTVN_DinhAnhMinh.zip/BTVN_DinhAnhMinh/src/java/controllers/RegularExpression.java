/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 *
 * @author DELL
 */
public class RegularExpression {
    public static void main(String[] args) {
        // Tạo biểu thức chính quy cho email
        String emailRegex = "^[A-Za-z0-9_]+@gmail\\.com$";
        String email = "anhmin05@gmail.com";
        
        // Tạo pattern từ biểu thức chính quy - truyền biểu thức chính quy vào pattern
        Pattern pt = Pattern.compile(emailRegex);
        
        // Khớp mẫu với chuỗi email, truyền email vào lớp matcher 
        Matcher mt = pt.matcher(email);
        
        // Kiểm tra
         if(mt.matches()) {
             System.out.println("Bieu thuc hop le");
         } else {
             System.out.println("Bieu thuc ko hop le");
         }
    }
}
